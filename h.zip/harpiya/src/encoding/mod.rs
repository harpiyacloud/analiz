//! Encoding and decoding.

pub(crate) mod base64;
pub(crate) mod hex;